function _classStaticPrivateMethodSet() {
  throw new TypeError("attempted to set read only static private field");
}

module.exports = _classStaticPrivateMethodSet;
module.exports["default"] = module.exports, module.exports.__esModule = true;